import re
def shortener(st: str) -> str:
    return re.sub(r'\(.*\)', '', st)
print(shortener('гойда(ллуц)'))

