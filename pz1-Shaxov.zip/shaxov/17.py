def remove_duplicates_and_spaces(input_string):
    input_string = input_string.replace(" ", "")
    result = ""
    for char in input_string:
        if char not in result:
            result += char
    return result
user_input = input()
output = remove_duplicates_and_spaces(user_input)
print(output)
