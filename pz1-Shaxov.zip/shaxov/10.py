s = input("Введите строку: ")
first_index = s.find('f')
last_index = s.rfind('f')
if first_index == -1:
    pass
elif first_index == last_index:
    print(first_index)
else:
    print(first_index, last_index)
