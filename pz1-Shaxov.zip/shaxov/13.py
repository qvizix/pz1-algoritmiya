str_input = input()
str_input = str_input.split('@')
str_input = ''.join(str_input)
print(str_input)