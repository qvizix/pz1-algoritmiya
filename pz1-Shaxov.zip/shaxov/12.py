s = input()
a = s.index('h')
s1 = s[:a]
s = s[a+1:][::-1]
a = s.index('h')
s3 = s[:a][::-1]
s = s[a+1:][::-1]
print(s1+s*2+s3)
