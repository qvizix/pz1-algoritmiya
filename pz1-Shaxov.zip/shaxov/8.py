input_string = input("Введите строку: ")
for i in range(1):
    print(input_string[2])
    print(input_string[-2])
    print(input_string[:5])
    print(input_string[:-2])
    print(input_string[::2])
    print(input_string[1::2])
    print(input_string[::-1])
    print(input_string[::-2])
    print(len(input_string))

